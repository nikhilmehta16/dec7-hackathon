
// Replace with your actual backend URL
export const API_BASE_URL = 'http://localhost:8000';
