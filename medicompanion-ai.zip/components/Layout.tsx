import React from 'react';
import { AppRoute } from '../types';
import { LayoutDashboardIcon, CalendarIcon, FileTextIcon, MessageSquareIcon } from './Icons';

interface LayoutProps {
  children: React.ReactNode;
  activeRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

const NavItem = ({ 
  icon, 
  label, 
  isActive, 
  onClick 
}: { 
  icon: React.ReactNode, 
  label: string, 
  isActive: boolean, 
  onClick: () => void 
}) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
      isActive 
        ? 'bg-primary-50 text-primary-700 font-medium' 
        : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
    }`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

export const Layout: React.FC<LayoutProps> = ({ children, activeRoute, onNavigate }) => {
  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <div className="w-64 border-r border-gray-200 flex flex-col bg-white">
        <div className="p-6">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center text-white font-bold">
              M
            </div>
            <span className="text-xl font-bold text-gray-900">MediCompanion</span>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <NavItem 
            icon={<LayoutDashboardIcon className="w-5 h-5" />} 
            label="Dashboard" 
            isActive={activeRoute === AppRoute.DASHBOARD} 
            onClick={() => onNavigate(AppRoute.DASHBOARD)} 
          />
          <NavItem 
            icon={<CalendarIcon className="w-5 h-5" />} 
            label="Appointments" 
            isActive={activeRoute === AppRoute.APPOINTMENTS} 
            onClick={() => onNavigate(AppRoute.APPOINTMENTS)} 
          />
          <NavItem 
            icon={<FileTextIcon className="w-5 h-5" />} 
            label="Medical Reports" 
            isActive={activeRoute === AppRoute.REPORTS} 
            onClick={() => onNavigate(AppRoute.REPORTS)} 
          />
          <NavItem 
            icon={<MessageSquareIcon className="w-5 h-5" />} 
            label="AI Assistant" 
            isActive={activeRoute === AppRoute.CHAT} 
            onClick={() => onNavigate(AppRoute.CHAT)} 
          />
        </nav>
        
        <div className="p-4 border-t border-gray-200">
           <div className="text-xs text-gray-400 text-center">v1.0.0 • Connected</div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-gray-50">
        {children}
      </main>
    </div>
  );
};