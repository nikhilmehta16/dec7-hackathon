
import { Appointment, MedicalReport, ReportSummary, Doctor } from '../types';
import { API_BASE_URL } from '../config';

// Helper for HTTP requests
const fetchJson = async (endpoint: string, options: RequestInit = {}) => {
  try {
    const res = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });
    if (!res.ok) {
        throw new Error(`API Error: ${res.statusText}`);
    }
    return await res.json();
  } catch (error) {
    console.error(`Error fetching ${endpoint}:`, error);
    throw error;
  }
};

export const StorageService = {
  // --- Doctors ---
  getDoctors: async (): Promise<Record<string, Doctor>> => {
    try {
        // Assumes backend has GET /doctors returning { "Dr. Name": { ... } }
        return await fetchJson('/doctors');
    } catch (e) {
        console.warn("Could not fetch doctors, using fallback", e);
        return {}; 
    }
  },

  getDoctor: async (name: string): Promise<Doctor | undefined> => {
    const doctors = await StorageService.getDoctors();
    return doctors[name];
  },

  // --- Appointments ---
  getAppointments: async (): Promise<Appointment[]> => {
    try {
        const res = await fetchJson('/appointments');
        return res.appointments || [];
    } catch (e) {
        return [];
    }
  },

  saveAppointment: async (doctor: string, time_slot: string): Promise<{ status: string; message: string; error_message?: string }> => {
    return await fetchJson('/appointments', {
        method: 'POST',
        body: JSON.stringify({ doctor, time_slot })
    });
  },

  modifyAppointment: async (current_doctor_name: string, current_time_slot: string, new_doctor_name?: string, new_time_slot?: string): Promise<{ status: string; message?: string; error_message?: string }> => {
      // Assumes backend has a specific endpoint or handles this via logic
      return await fetchJson('/appointments/modify', {
          method: 'POST',
          body: JSON.stringify({
              current_doctor_name,
              current_time_slot,
              new_doctor_name,
              new_time_slot
          })
      });
  },

  cancelAppointment: async (doctor: string, time_slot: string): Promise<{ status: string; message: string; error_message?: string }> => {
    return await fetchJson('/appointments/cancel', {
        method: 'POST', // Using POST for complex deletion args, or could be DELETE with body
        body: JSON.stringify({ doctor_name: doctor, time_slot })
    });
  },

  // --- Reports ---
  getReports: async (): Promise<MedicalReport[]> => {
      try {
        const res = await fetchJson('/reports/list_full'); // Assumes endpoint returning full report objects
        // OR if backend only has list names, we might need to fetch content individually.
        // For now, assuming backend returns list of metadata + content for the UI
        return res.reports || [];
      } catch (e) {
          return [];
      }
  },

  // If the backend only provides filenames via list_medical_reports, we might use this
  getReportNames: async (): Promise<string[]> => {
      const res = await fetchJson('/reports');
      return res.reports || [];
  },

  getReportsSummary: async (): Promise<{ status: string; summaries: any[] }> => {
      return await fetchJson('/reports/summary');
  },

  saveReport: async (filename: string, content: string): Promise<{ status: string; message: string; summary: ReportSummary }> => {
    return await fetchJson('/reports', {
        method: 'POST',
        body: JSON.stringify({ filename, content })
    });
  },

  getReportContent: async (filename: string): Promise<string | null> => {
      try {
        const res = await fetchJson(`/reports/${filename}`);
        return res.content;
      } catch (e) {
          return null;
      }
  },

  // --- Medicine ---
  orderMedicine: async (medicine_name: string, quantity: number): Promise<{ status: string; message: string }> => {
      return await fetchJson('/medicine/order', {
          method: 'POST',
          body: JSON.stringify({ medicine_name, quantity })
      });
  }
};
