
import { API_BASE_URL } from '../config';

export interface Attachment {
    mimeType: string;
    data: string; // Base64
}

export class GeminiService {
  private sessionId: string;

  constructor() {
    // Generate a simple session ID for the backend to track context
    this.sessionId = Math.random().toString(36).substring(7);
  }

  public async sendMessage(message: string, attachment?: Attachment): Promise<string> {
    try {
      const payload: any = {
          prompt: message,
          session_id: this.sessionId
      };

      // If there is an attachment, we send it. 
      // Adjust keys (file_data, file_type) based on your backend expectation.
      if (attachment) {
          payload.file_data = attachment.data; // Base64
          payload.mime_type = attachment.mimeType;
          payload.filename = "upload"; // Generic name or pass real name if available
      }

      const response = await fetch(`${API_BASE_URL}/agent/chat`, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
      });

      if (!response.ok) {
          throw new Error(`Backend Error: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Assumes backend returns { "response": "Agent text response" }
      return data.response || data.text || "No response text received.";

    } catch (error) {
      console.error("Agent API Error:", error);
      return "I'm having trouble connecting to the medical server. Please ensure the backend is running.";
    }
  }
}

export const geminiService = new GeminiService();
